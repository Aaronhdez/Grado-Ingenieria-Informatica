using NUnit.Framework;

namespace Bank_Kata.Test {
    public class Tests {
        [SetUp]
        public void Setup() {
        }

        [Test]
        public void Test1() {
            Assert.Pass();
        }
    }
}