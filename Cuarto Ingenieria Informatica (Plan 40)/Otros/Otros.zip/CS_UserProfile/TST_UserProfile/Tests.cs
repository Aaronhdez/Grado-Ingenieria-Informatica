using NUnit.Framework;
using WF_UserProfile.model;

namespace TST_UserProfile
{
    public class Tests
    {
        private User johnDoe;
        private User marySue;
        private User peterPotts;

        [SetUp]
        public void Setup()
        {
            this.johnDoe = new User("John", "Doe", 17, "5, EdgarStreet", "JohnDoe@domain.com", "JohnDoe_001");
            this.marySue = new User("Mary", "Sue", 16, "6, EdgarStreet", "MarySue@domain.com", "MarySue_001");
            this.peterPotts = new User("Peter", "Potts", 23, "7, EdgarStreet", "PeterPotts@domain.com", "PeterPotts_001");
        }

        [Test]
        public void Test1()
        {
            Assert.AreEqual(johnDoe.Name, "John");
            Assert.AreEqual(peterPotts.Name, "Peter");
            Assert.AreEqual(marySue.Name, "Mary");
            Assert.AreNotEqual(marySue.Name, peterPotts.Name);
            Assert.AreNotEqual(johnDoe.Name, peterPotts.Name);
            Assert.AreNotEqual(marySue.Name, johnDoe.Name);
            Assert.Pass();
        }

        [Test]
        public void Test2()
        {
            Assert.AreEqual(johnDoe.Name, "John");
            Assert.AreEqual(peterPotts.Name, "Peter");
            Assert.AreEqual(marySue.Name, "Mary");
            Assert.AreNotEqual(marySue.Name, peterPotts.Name);
            Assert.AreNotEqual(johnDoe.Name, peterPotts.Name);
            Assert.AreNotEqual(marySue.Name, johnDoe.Name);
            Assert.Pass();
        }
    }
}