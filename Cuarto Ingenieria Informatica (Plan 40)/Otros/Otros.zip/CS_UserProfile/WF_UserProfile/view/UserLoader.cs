﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_UserProfile.model;

namespace WF_UserProfile.view
{
    interface UserLoader
    {
        User Load();
    }
}
