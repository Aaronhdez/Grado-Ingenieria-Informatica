﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_UserProfile.model;
using static WF_UserProfile.model.UserData;

namespace WF_UserProfile.view
{
    interface UserDisplay : Observer
    {
        void Display(UserData user);
    }
}
