﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_UserProfile.model;
using WF_UserProfile.view;

namespace WF_UserProfile.app
{
    class MockUserLoader : UserLoader
    {
        public User Load()
        {
            return new User("John", "Doe", 17, "5, EdgarStreet", "JohnDoe@domain.com", "JohnDoe_001");
        }
    }
}
