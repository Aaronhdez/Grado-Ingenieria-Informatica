﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_UserProfile.model
{
    public class User
    {
        private string name;
        private string surname;
        private int age;
        private string address;
        private string email;
        private string username;

        public User()
        {

        }

        public User(string v1, string v2, int v3, string v4, string v5, string v6)
        {
            this.Name = v1;
            this.Address = v2;
            this.Age = v3;
            this.Address = v4;
            this.Email = v5;
            this.Username = v6;
        }

        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public int Age { get => age; set => age = value; }
        public string Address { get => address; set => address = value; }
        public string Email { get => email; set => email = value; }
        public string Username { get => username; set => username = value; }

    }
}
