﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_UserProfile.view;
using static WF_UserProfile.model.User;

namespace WF_UserProfile.model
{
    public class UserData
    {
        private User user;
        private UserLoader userLoader;
        private List<Observer> observers;

        public UserData()
        {
            this.user = this.userLoader.Load();
        }

        public string getUserName() {
            return this.user.Name;
        }

        /**
         * MVC
         */

        public void Subscribe(Observer obs)
        {
            this.observers.Add(obs);
        }

        public void Unsubscribe(Observer obs)
        {
            this.observers.Remove(obs);
        }

        public interface Observer
        {
            void Change();
        }
    }
}
