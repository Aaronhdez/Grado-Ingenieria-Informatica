# CS_UserProfile

A simple User Profile Managing Tool coded in C# usign TDD developmnet standard
