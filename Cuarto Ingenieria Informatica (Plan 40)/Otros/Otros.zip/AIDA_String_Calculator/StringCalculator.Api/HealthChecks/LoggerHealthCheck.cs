﻿using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace StringCalculator.Api.HealthChecks
{
    public class LoggerHealthCheck: IHealthCheck
    {
        const string LOGS_FOLDER = "../Logs";
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default(CancellationToken))
        {
            var healthCheckResultHealthy = Directory.Exists(LOGS_FOLDER);
            if (healthCheckResultHealthy)
            {
                return Task.FromResult(
                    HealthCheckResult.Healthy("String Calculator Logs directory is present."));
            }

            return Task.FromResult(
                new HealthCheckResult(context.Registration.FailureStatus,
                    "String Calculator Logs directory is NOT present."));
        }
    }
}
