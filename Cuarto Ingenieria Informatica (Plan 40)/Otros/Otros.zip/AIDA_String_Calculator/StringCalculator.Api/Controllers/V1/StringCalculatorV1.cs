﻿using Microsoft.AspNetCore.Mvc;
using System;
using StringCalculator.Application.Actions;

namespace StringCalculator.Api.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/StringCalculatorV1")]
    [ApiController]
    [Produces("application/json")]
    public class StringCalculatorV1 : ControllerBase
    {
        private readonly GetStringCalculatorV1 _stringCalculatorV1;

        public StringCalculatorV1(GetStringCalculatorV1 stringCalculatorV1)
        {
            this._stringCalculatorV1 = stringCalculatorV1;
        }

        [HttpGet]
        public ActionResult<string> Get([FromQuery] string input)
        {
            try
            {
                var parsedInput = input.Replace("\\n", "\n");
                return Ok(_stringCalculatorV1.Execute(parsedInput));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
