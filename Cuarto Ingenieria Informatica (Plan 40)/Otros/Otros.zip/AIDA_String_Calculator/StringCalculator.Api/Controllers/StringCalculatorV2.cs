﻿using Microsoft.AspNetCore.Mvc;
using System;
using StringCalculator.Application.Actions;

namespace StringCalculator.Api.Controllers
{
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/StringCalculatorV2")]
    [ApiController]
    [Produces("application/json")]
    public class StringCalculatorV2 : ControllerBase
    {
        private readonly GetStringCalculatorV2 _stringCalculatorV2;

        public StringCalculatorV2(GetStringCalculatorV2 stringCalculatorV2)
        {
            this._stringCalculatorV2 = stringCalculatorV2;
        }

        [HttpGet]
        public ActionResult<string> Get([FromQuery] string input)
        {
            try
            {
                var parsedInput = input.Replace("\\n", "\n");
                return Ok(_stringCalculatorV2.Execute(parsedInput));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}