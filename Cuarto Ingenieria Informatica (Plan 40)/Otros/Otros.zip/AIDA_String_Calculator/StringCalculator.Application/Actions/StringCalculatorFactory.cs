﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using StringCalculator.Application.Model;

namespace StringCalculator.Application.Actions
{
    public class StringCalculatorFactory
    {
        public static GetStringCalculator Create(string version, ILogger logger)
        {
            switch (version)
            {
                case "2":
                    return CreateStringCalculatorV2(logger);
                default:
                    return CreateStringCalculatorV1(logger);
            }
        }

        public static GetStringCalculator CreateStringCalculatorV1(ILogger logger)
        {
            return new GetStringCalculatorV1(logger);
        }

        public static GetStringCalculator CreateStringCalculatorV2(ILogger logger)
        {
            return new GetStringCalculatorV2(logger);
        }
    }

    public interface GetStringCalculator
    {
        public string Execute(string input);
    }
}
