﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class NullCommand : Command
    {
        public static Command Instance = new NullCommand();
        public void execute()
        {

        }
    }
}
