﻿using MovieMockFrame.control;
using MovieMockFrame.model;

namespace MovieMockFrame.app
{
    internal class PrevCommand : Command
    {
        private MovieData movieData;

        public PrevCommand(MovieData movieData)
        {
            this.movieData = movieData;
        }
        public void execute()
        {
            this.movieData.Prev();
        }
    }
}