﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class ExitCommand : Command
    {
        public void execute()
        {
            Environment.Exit(0);
        }
    }
}
