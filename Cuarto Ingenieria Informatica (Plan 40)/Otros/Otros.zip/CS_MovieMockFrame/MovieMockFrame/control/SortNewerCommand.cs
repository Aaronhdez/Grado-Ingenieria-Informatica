﻿using MovieMockFrame.control;
using MovieMockFrame.model;

namespace MovieMockFrame.app
{
    internal class SortNewerCommand : Command
    {
        private MovieData moviesList;
        public SortNewerCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }
        public void execute()
        {
            this.moviesList.AutoSort("newer");
        }
    }
}