﻿using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class NextCommand : Command
    {
        private MovieData movieData;

        public NextCommand(MovieData movieData) {
            this.movieData = movieData;
        }
        
        public void execute()
        {
            this.movieData.Next();
        }
    }
}
