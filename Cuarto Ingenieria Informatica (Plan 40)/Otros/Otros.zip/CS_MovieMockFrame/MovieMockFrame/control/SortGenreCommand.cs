﻿using MovieMockFrame.control;
using MovieMockFrame.model;

namespace MovieMockFrame.app
{
    internal class SortGenreCommand : Command
    {
        private MovieData moviesList;
        public SortGenreCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }

        public void execute()
        {
            this.moviesList.AutoSort("genre");
        }
    }
}