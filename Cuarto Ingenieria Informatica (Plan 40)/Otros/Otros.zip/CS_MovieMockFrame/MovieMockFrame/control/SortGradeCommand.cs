﻿using MovieMockFrame.control;
using MovieMockFrame.model;

namespace MovieMockFrame.control
{
    internal class SortGradeCommand : Command
    {
        private MovieData moviesList;
        public SortGradeCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }

        public void execute()
        {
            this.moviesList.AutoSort("grade");
        }
    }
}