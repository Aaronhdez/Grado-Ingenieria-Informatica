﻿using MovieMockFrame.control;
using MovieMockFrame.model;

namespace MovieMockFrame.app
{
    internal class SortViewCommand : Command
    {
        private MovieData moviesList;
        public SortViewCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }
        public void execute()
        {
            this.moviesList.AutoSort("views");
        }
    }
}