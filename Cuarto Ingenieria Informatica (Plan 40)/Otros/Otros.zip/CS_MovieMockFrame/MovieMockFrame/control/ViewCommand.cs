﻿using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class ViewCommand : Command
    {
        private MovieData moviesList;
        public ViewCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }

        public void execute()
        {
            ((Movie)this.moviesList.GetCurrentMovie()).view();
            Console.WriteLine("Playing: " + ((Movie) this.moviesList.GetCurrentMovie()).Title);
            System.Threading.Thread.Sleep(3000);
            Console.WriteLine("The end!");
            System.Threading.Thread.Sleep(1000);
            this.moviesList.Reload();
        }
    }
}
