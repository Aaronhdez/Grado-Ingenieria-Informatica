﻿using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class ReloadCommand : Command
    {
        private MovieData moviesList;
        public ReloadCommand(MovieData moviesList)
        {
            this.moviesList = moviesList;
        }

        public void execute()
        {
            this.moviesList.Reload();
        }
    }
}
