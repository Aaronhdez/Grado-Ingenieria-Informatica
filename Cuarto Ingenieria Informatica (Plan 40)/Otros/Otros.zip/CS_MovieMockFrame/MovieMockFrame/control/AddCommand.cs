﻿using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.control
{
    class AddCommand : Command
    {
        private MovieData movieData;

        public AddCommand(MovieData movieData)
        {
            this.movieData = movieData;
        }
        public void execute()
        {
            this.movieData.AddMovie();
        }
    }
}
