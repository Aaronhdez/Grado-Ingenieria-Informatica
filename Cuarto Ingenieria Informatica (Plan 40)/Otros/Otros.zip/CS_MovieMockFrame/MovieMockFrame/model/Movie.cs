﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.model
{
    class Movie
    {
        private String title;
        private String year;
        private String genre;
        private String image;
        private String actors;
        private double grade;
        private int views;

        public Movie(String title, String year, String genre, String image, String actors, int views, double grade)
        {
            this.title = title;
            this.year = year;
            this.genre = genre;
            this.image = image;
            this.actors = actors;
            this.Views = views;
            this.grade = grade;
        }


        public string Title { get => title; set => title = value; }

        public string Year { get => year; set => year = value; }

        public string Genre { get => genre; set => genre = value; }

        public double Grade { get => grade; set => grade = value; }

        public string Actors { get => actors; set => actors = value; }

        public string Image { get => image; set => image = value; }
        public int Views { get => views; set => views = value; }

        public void view() {
            this.Views += 1;
        }

        public override string ToString()
        {
            return this.title + " | " + this.year + " | " + this.genre
                + " | " + this.image + " | " + this.actors
                + " | Visualizaciones: " + this.views +  " | Nota media: " + this.grade;
        }


    }
}
