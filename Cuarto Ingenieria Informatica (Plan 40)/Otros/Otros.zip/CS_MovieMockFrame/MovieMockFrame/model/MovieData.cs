﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace MovieMockFrame.model
{
    class MovieData
    {
        private ArrayList moviesList;
        private ArrayList observersList;
        private Movie currentMovie;
        private int index;

        public MovieData(ArrayList load)
        {
            this.observersList = new ArrayList();
            this.moviesList = load;
            this.index = 0;
            this.currentMovie = (Movie) this.moviesList[0];
        }

        /**
         * Commands;
         */

        internal void Next()
        {
            if (this.index == this.moviesList.Count - 1) { 
                this.index = 0; 
            } else { 
                this.index += 1; 
            }
            this.currentMovie = (Movie) this.moviesList[this.index];
            Console.Clear();
            this.ChangeStatus();
        }

        internal void Prev()
        {
            if (this.index == 0)
            {
                this.index = this.moviesList.Count - 1;
            }
            else
            {
                this.index -= 1;
            }
            this.currentMovie = (Movie) this.moviesList[this.index];
            Console.Clear();
            this.ChangeStatus();
        }

        internal void Reload()
        {
            this.index = 0;
            this.currentMovie = (Movie) this.moviesList[this.index];
            Console.Clear();
            this.ChangeStatus();
        }

        internal void AutoSort(string opt)
        {
            switch (opt) {
                case "views":
                    this.SortByViews();
                    Console.WriteLine("ORDEN: Más vistas");
                    break;
                case "grade":
                    this.SortByGrade();
                    Console.WriteLine("ORDEN: Calificación");
                    break;
                case "newer":
                    this.SortByNewer();
                    Console.WriteLine("ORDEN: Nás reciente");
                    break;
                case "genre":
                    this.SortByGenre();
                    Console.WriteLine("ORDEN: Género");
                    break;
            }
            //this.index = this.moviesList.IndexOf(this.currentMovie);
            this.Reload();
        }

        public void AddMovie()
        {
            Console.WriteLine("Inserte Títutlo");
            String title = Console.ReadLine();
            
            Console.WriteLine("Inserte Año");
            String year = Console.ReadLine();
            
            Console.WriteLine("Inserte Género");
            String genre = Console.ReadLine();
            
            Console.WriteLine("Inserte Imagen");
            String image = Console.ReadLine();
            
            Console.WriteLine("Inserte Actores");
            String cast = Console.ReadLine();
            
            Console.WriteLine("Inserte visualizaciones");
            String views = Console.ReadLine();
            int intViews;
            while (!Int32.TryParse(views, out intViews))
            {
                Console.WriteLine("Inserte nota");
                views = Console.ReadLine();
            }

            Console.WriteLine("Inserte nota");
            String grade = Console.ReadLine();
            double dbGrade;
            while (!double.TryParse(grade, out dbGrade))
            {
                Console.WriteLine("Inserte nota");
                grade = Console.ReadLine();
            }

            this.moviesList.Add(new Movie(title, year, genre, image, cast, intViews, dbGrade));
            this.Reload();
        }

        public void RemoveMovie() {
            Console.Clear();
            int i = 0;
            foreach (Movie movie in this.moviesList) {
                Console.WriteLine(i+". "+movie.Title);
                i++;
            }
            Console.WriteLine("\n Para borrar la película, escriba su número");
            String movieIndexStr = Console.ReadLine();
            int movieIndex;
            while (!Int32.TryParse(movieIndexStr, out movieIndex)) {
                Console.WriteLine("\n Para borrar la película, escriba su número");
                movieIndexStr = Console.ReadLine();
            }

            this.moviesList.RemoveAt(movieIndex);
            this.Reload();
        }

        private void SortByGenre()
        {
            this.moviesList.Sort(new GenreComparer());
        }

        private void SortByNewer()
        {
            this.moviesList.Sort(new NewerComparer());
        }

        private void SortByGrade()
        {
            this.moviesList.Sort(new GradeComparer());
        }

        private void SortByViews()
        {
            this.moviesList.Sort(new ViewsComparer());
        }


        /**
         * Comparators
         */

        private class GenreComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Movie m1 = (Movie) x;
                Movie m2 = (Movie) y;
                return String.Compare(m1.Genre, m2.Genre);
            }
        }

        private class NewerComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Movie m1 = (Movie) x;
                Movie m2 = (Movie) y;
                return m1.Year.CompareTo(m2.Year);
            }
        }

        private class GradeComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Movie m1 = (Movie)x;
                Movie m2 = (Movie)y;
                return -(m1.Grade.CompareTo(m2.Grade));
            }
        }

        private class ViewsComparer : IComparer
        {
            public int Compare(object x, object y)
            {
                Movie m1 = (Movie)x;
                Movie m2 = (Movie)y;
                return m1.Views.CompareTo(m2.Views);
            }
        }

        /**
         * Features
         */

        public void Add(Movie movie)
        {
            this.moviesList.Add(movie);
        }

        public ArrayList GetMoviesList()
        {
            return moviesList;
        }

        public Movie GetCurrentMovie()
        {
            return this.currentMovie;
        }

        public override string ToString()
        {
            String res = "";
            foreach (Movie movie in this.moviesList)
            { 
                res += movie.ToString() + "\r\n";
            }
            return res;
        }

        //MVC
        public void RegisterObservers(Observer obs) {
            this.observersList.Add(obs);
        }

        private void ChangeStatus() {
            foreach (Observer observer in this.observersList){
                observer.Change();
            }
        }

        public interface Observer {
            void Change();
        }
    }
}
