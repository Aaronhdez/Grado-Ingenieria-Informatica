﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieMockFrame.model;

namespace MovieMockFrame.view
{
    interface MoviesDisplay: MovieData.Observer
    {
        void display(MovieData movieData);
    }
}
