﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using MovieMockFrame.model;

namespace MovieMockFrame.view
{
    interface MoviesLoader
    {
        ArrayList load();
    }
}
