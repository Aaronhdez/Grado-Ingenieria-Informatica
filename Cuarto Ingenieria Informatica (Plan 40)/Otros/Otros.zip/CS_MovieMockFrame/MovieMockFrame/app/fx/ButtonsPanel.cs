﻿using MovieMockFrame.control;
using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieMockFrame.app.fx
{
    class ButtonsPanel : TableLayoutPanel
    {
        private MovieData movieData;
        private Dictionary<String, Command> commands;

        private Button byGenreButton;
        private Button byGradeButton;
        private Button byViewsButton;
        private Button byNewerButton;

        public ButtonsPanel(MovieData movieData, Dictionary<String, Command> commands)
        {
            this.movieData = movieData;
            this.commands = commands;
            this.StartFX();
        }

        private void StartFX()
        {
            //Assets
            this.StartAssets();
            
            //This
            //this.AutoSize = true;
            this.ColumnCount = 1;
            this.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.RowCount = 4;
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            //this.BackColor = SystemColors.Window;
            this.Location = new Point(515, 5);
            this.Name = "buttonsPanel";
            this.Size = new Size(150, 200);
            this.TabIndex = 1;

        }

        private void StartAssets()
        {
            //GenreButton 
            this.byGenreButton = new Button();
            this.byGenreButton.BackColor = System.Drawing.SystemColors.Control;
            this.byGenreButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.byGenreButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byGenreButton.Location = new System.Drawing.Point(5, 5);
            this.byGenreButton.Name = "byGenreButton";
            this.byGenreButton.Size = new System.Drawing.Size(100, 35);
            this.byGenreButton.Text = "Por género";
            this.byGenreButton.UseVisualStyleBackColor = false;
            this.byGenreButton.Click += new System.EventHandler(this.SortGenre_Click);

            //ByViewsButton 
            this.byViewsButton = new Button();
            this.byViewsButton.BackColor = System.Drawing.SystemColors.Control;
            this.byViewsButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.byViewsButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byViewsButton.Location = new System.Drawing.Point(5, 5);
            this.byViewsButton.Name = "byViewsButton";
            this.byViewsButton.Size = new System.Drawing.Size(100, 35);
            this.byViewsButton.Text = "Por Visualizaciones";
            this.byViewsButton.UseVisualStyleBackColor = false;
            this.byViewsButton.Click += new System.EventHandler(this.SortViews_Click);

            //GradeButton 
            this.byGradeButton = new Button();
            this.byGradeButton.BackColor = System.Drawing.SystemColors.Control;
            this.byGradeButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.byGradeButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byGradeButton.Location = new System.Drawing.Point(5, 5);
            this.byGradeButton.Name = "byGradeButton";
            this.byGradeButton.Size = new System.Drawing.Size(100, 35);
            this.byGradeButton.Text = "Por Calificación";
            this.byGradeButton.UseVisualStyleBackColor = false;
            this.byGradeButton.Click += new System.EventHandler(this.SortGrade_Click);

            //NewerButton 
            this.byNewerButton = new Button();
            this.byNewerButton.BackColor = System.Drawing.SystemColors.Control;
            this.byNewerButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.byNewerButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.byNewerButton.Location = new System.Drawing.Point(5, 5);
            this.byNewerButton.Name = "byNewerButton";
            this.byNewerButton.Size = new System.Drawing.Size(100, 35);
            this.byNewerButton.Text = "Más recientes";
            this.byNewerButton.UseVisualStyleBackColor = false;
            this.byNewerButton.Click += new System.EventHandler(this.SortGrade_Click);

            this.Controls.Add(this.byGenreButton, 0, 0);
            this.Controls.Add(this.byGradeButton, 0, 1);
            this.Controls.Add(this.byViewsButton, 0, 2);
            this.Controls.Add(this.byNewerButton, 0, 3);


        }

        //Functions
        private void SortGrade_Click(object sender, EventArgs e)
        {
            this.commands["by_grade"].execute();
        }
        private void SortViews_Click(object sender, EventArgs e)
        {
            this.commands["by_views"].execute();
        }
        private void SortGenre_Click(object sender, EventArgs e)
        {
            this.commands["by_genre"].execute();
        }
    }
}
