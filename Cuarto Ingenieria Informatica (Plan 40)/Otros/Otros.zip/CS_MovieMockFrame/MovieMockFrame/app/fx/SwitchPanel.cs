﻿using MovieMockFrame.control;
using MovieMockFrame.model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieMockFrame.app.fx
{
    class SwitchPanel : TableLayoutPanel
    {
        private MovieData movieData;
        private Dictionary<String, Command> commands;

        private Button nextButton;
        private Button prevButton;
        private Button playButton;

        public SwitchPanel(MovieData movieData, Dictionary<string, Command> commands)
        {
            this.movieData = movieData;
            this.commands = commands;
            this.StartFX();
        }

        private void StartFX()
        {
            this.StartAssets();

            this.ColumnCount = 1;
            this.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.RowCount = 4;
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            //this.BackColor = SystemColors.Window;
            this.Location = new Point(515, 255);
            this.Name = "switchPanel";
            this.Size = new Size(150, 200);
            this.TabIndex = 1;
        }

        private void StartAssets()
        {
            //GenreButton 
            this.nextButton = new Button();
            this.nextButton.BackColor = System.Drawing.SystemColors.Control;
            this.nextButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nextButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextButton.Location = new System.Drawing.Point(5, 5);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(100, 35);
            this.nextButton.Text = ">>";
            this.nextButton.UseVisualStyleBackColor = false;
            this.nextButton.Click += new System.EventHandler(this.Next_Click);

            //prevButton 
            this.prevButton = new Button();
            this.prevButton.BackColor = System.Drawing.SystemColors.Control;
            this.prevButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.prevButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prevButton.Location = new System.Drawing.Point(5, 5);
            this.prevButton.Name = "prevButton";
            this.prevButton.Size = new System.Drawing.Size(100, 35);
            this.prevButton.Text = "<<";
            this.prevButton.UseVisualStyleBackColor = false;
            this.prevButton.Click += new System.EventHandler(this.Prev_Click);

            //GradeButton 
            this.playButton = new Button();
            this.playButton.BackColor = System.Drawing.SystemColors.Control;
            this.playButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.playButton.Font = new System.Drawing.Font("Microsoft Tai Le", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playButton.Location = new System.Drawing.Point(5, 5);
            this.playButton.Name = "playButton";
            this.playButton.Size = new System.Drawing.Size(100, 35);
            this.playButton.Text = "Reproducir";
            this.playButton.UseVisualStyleBackColor = false;
            this.playButton.Click += new System.EventHandler(this.Grade_Click);


            this.Controls.Add(this.nextButton, 0, 1);
            this.Controls.Add(this.prevButton, 0, 2);
            this.Controls.Add(this.playButton, 0, 3);
        }

        private void Grade_Click(object sender, EventArgs e)
        {
            this.commands["play"].execute();
        }

        private void Prev_Click(object sender, EventArgs e)
        {
            this.commands["prev"].execute();
        }

        private void Next_Click(object sender, EventArgs e)
        {
            this.commands["next"].execute();
        }
    }
}
