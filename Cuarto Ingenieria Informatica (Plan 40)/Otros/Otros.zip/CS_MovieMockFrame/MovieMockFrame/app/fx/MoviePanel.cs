﻿using MovieMockFrame.model;
using MovieMockFrame.view;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace MovieMockFrame.app
{
    class MoviePanel : Panel, MoviesDisplay
    {
        private TextBox moviesArea;
        private MovieData movieData;

        public MoviePanel()
        {
            this.StartFX();
        }

        private void StartFX()
        {
            //This frame
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            //this.BackColor = SystemColors.Window;
            this.Location = new Point(5, 5);
            this.Name = "textPanel";
            this.Size = new Size(510, 400);
            this.TabIndex = 1;

            //MovieArea
            this.moviesArea = new TextBox();
            this.moviesArea.BackColor = SystemColors.Window;
            this.moviesArea.Multiline = true;
            this.moviesArea.Cursor = Cursors.Default;
            this.moviesArea.Location = new Point(5, 5);
            this.moviesArea.Size = new Size(500, 390);
            this.moviesArea.TextAlign = HorizontalAlignment.Left;
            this.moviesArea.ReadOnly = true;
            this.moviesArea.TabIndex = 1;
            this.Controls.Add(moviesArea);
        }

        public void display(MovieData movieData)
        {
            this.movieData = movieData;
            this.moviesArea.Text = this.movieData.ToString();
        }

        public void Change()
        {
            this.moviesArea.Text = this.movieData.ToString();
        }
    }
}
