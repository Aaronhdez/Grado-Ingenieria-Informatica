﻿using MovieMockFrame.model;
using MovieMockFrame.view;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieMockFrame.app.fx
{
    class SelectedMoviePanel : TableLayoutPanel, MoviesDisplay
    {
        private MovieData movieData;
        private TextBox currentMovieTextBox;

        public SelectedMoviePanel()
        {
            this.StartFX();
        }

        private void StartFX()
        {
            //Assets
            this.StartAssets();

            //This
            this.Location = new Point(5, 415);
            this.Size = new Size(510, 50);
            this.Name = "selectedMoviePanel";

            this.Controls.Add(this.currentMovieTextBox);
        }

        private void StartAssets()
        {
            this.currentMovieTextBox = new TextBox();
            this.currentMovieTextBox.Location = new Point(5, 5);
            this.currentMovieTextBox.Size = new Size(500, 25);
        }

        public void Change()
        {
            this.currentMovieTextBox.Text = this.movieData.GetCurrentMovie().Title;
        }

        public void display(MovieData movieData)
        {
            this.movieData = movieData;
            this.currentMovieTextBox.Text = this.movieData.GetCurrentMovie().Title;
        }
    }
}
