﻿using MovieMockFrame.app.fx;
using MovieMockFrame.control;
using MovieMockFrame.model;
using MovieMockFrame.view;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieMockFrame.app
{
    class MovieFrame : Form
    {
        private System.ComponentModel.IContainer components = null;
        private ButtonsPanel buttonsPanel;
        private SelectedMoviePanel selectedMoviePanel;
        private SwitchPanel switchPanel;

        private MovieData moviesList;
        private MoviesLoader moviesLoader;
        private MoviesDisplay moviePanel;
        private Dictionary<String, Command> commands;

        public MovieFrame()
        {
            this.Execute();
        }

        private void Execute()
        {
            this.StartLogic();
            this.StartFX();
        }

        private void StartLogic()
        {
            //Instances
            this.moviesLoader = new MockLoader();
            this.moviePanel = new MoviePanel();
            this.selectedMoviePanel = new SelectedMoviePanel();
            this.moviesList = new MovieData(this.moviesLoader.load());

            //Two-Way Bindings on MVC components
            this.moviesList.RegisterObservers(this.selectedMoviePanel);
            this.moviesList.RegisterObservers(this.moviePanel);
            this.selectedMoviePanel.display(this.moviesList);
            this.moviePanel.display(this.moviesList);

            //Commands initialization
            this.CreateCommands();
            this.buttonsPanel = new ButtonsPanel(this.moviesList, this.commands);
            this.switchPanel = new SwitchPanel(this.moviesList, this.commands);
        }

        private void CreateCommands()
        {
            this.commands = new Dictionary<String, Command>
            {
                { "add", new AddCommand(this.moviesList) },
                { "remove", new RemoveCommand(this.moviesList) },
                { "show", new ReloadCommand(this.moviesList) },
                { "next", new NextCommand(this.moviesList) },
                { "prev", new PrevCommand(this.moviesList) },
                { "by_genre", new SortGenreCommand(this.moviesList) },
                { "by_grade", new SortGradeCommand(this.moviesList) },
                { "by_newer", new SortNewerCommand(this.moviesList) },
                { "by_views", new SortViewCommand(this.moviesList) },
                { "play", new ViewCommand(this.moviesList) },
                { "quit", new ExitCommand() }
            };
        }

        private void StartFX()
        {
            //Movies Panel
            this.Controls.Add((Panel) this.moviePanel);

            //ButtonsPanel
            this.Controls.Add(this.buttonsPanel);

            //SelectedMoviePanel
            this.Controls.Add(this.selectedMoviePanel);

            //SwitchPanel
            this.Controls.Add(this.switchPanel);

            //This
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(680, 510);
            this.MaximizeBox = true;
            this.Name = "MovieMockFrame";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Movie Selector";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
