﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieMockFrame.model;
using MovieMockFrame.view;
using MovieMockFrame.control;
using System.Collections;

namespace MovieMockFrame.app
{
    class MockFrame
    {
        private MoviesDisplay movieMockPanel;
        private MoviesDisplay currentMovieMockPanel;
        private MovieData moviesList;
        private Dictionary<String, Command> commands;
        private MoviesLoader moviesMockLoader;

        public MockFrame(){
            this.execute();
        }

        private void execute()
        {
            this.movieMockPanel = new MockPanel();
            this.currentMovieMockPanel = new MovieMockPanel();
            this.moviesMockLoader = new MockLoader();
            this.moviesList = new MovieData(this.moviesMockLoader.load());
            this.initLogic();
            Console.WriteLine("Loaded!");
            this.start();
        }


        private void initLogic()
        {
            this.moviesList.RegisterObservers(this.movieMockPanel);
            this.movieMockPanel.display(moviesList);
            this.moviesList.RegisterObservers(this.currentMovieMockPanel);
            this.currentMovieMockPanel.display(moviesList);
            this.createCommands();
        }

        private void start()
        {
            ((Command)this.commands["show"]).execute();
            while (true) {
                String command = Console.ReadLine();
                Command dummy = null;
                if (this.commands.TryGetValue(command, out dummy)) {
                    ((Command) commands[command]).execute();
                } else { 
                    NullCommand.Instance.execute(); 
                }
            }
        }

        private void createCommands()
        {
            this.commands = new Dictionary<String, Command>();
            this.commands.Add("add", new AddCommand(this.moviesList));
            this.commands.Add("remove", new RemoveCommand(this.moviesList));
            this.commands.Add("show", new ReloadCommand(this.moviesList));
            this.commands.Add("next", new NextCommand(this.moviesList));
            this.commands.Add("prev", new PrevCommand(this.moviesList));
            this.commands.Add("by_genre", new SortGenreCommand(this.moviesList));
            this.commands.Add("by_grade", new SortGradeCommand(this.moviesList));
            this.commands.Add("by_newer", new SortNewerCommand(this.moviesList));
            this.commands.Add("by_views", new SortViewCommand(this.moviesList));
            this.commands.Add("play", new ViewCommand(this.moviesList));
            this.commands.Add("quit", new ExitCommand());
        }
    }
}
