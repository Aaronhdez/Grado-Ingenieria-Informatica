﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MovieMockFrame.model;
using MovieMockFrame.view;

namespace MovieMockFrame.app
{
    class MovieMockPanel : MoviesDisplay
    {

        private MovieData movieData;

        public MovieMockPanel() {
            this.execute();
        }

        private void execute()
        {
            //Graphical Assets
        }

        public void Change()
        {
            Console.WriteLine("\nPelícula Actual: " + ((Movie) this.movieData.GetCurrentMovie()).Title);
            Console.WriteLine("--------------------------------------");
        }

        public void display(MovieData movieData)
        {
            this.movieData = movieData;
        }
    }
}
