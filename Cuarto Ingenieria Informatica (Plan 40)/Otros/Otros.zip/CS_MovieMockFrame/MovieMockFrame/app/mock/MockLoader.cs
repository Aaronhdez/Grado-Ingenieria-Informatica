﻿using MovieMockFrame.model;
using MovieMockFrame.view;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.app
{
    class MockLoader : MoviesLoader
    {
        public ArrayList load()
        {
            ArrayList res = new ArrayList();
            res.Add(new Movie("El silencio de los corderos", "1999", "Terror", "Imagen1", "Actores", 3, 8.5));
            res.Add(new Movie("Hannibal Lecter", "1992", "Terror", "Imagen2", "Actores2", 2, 7.5));
            res.Add(new Movie("La Roca", "1992", "Acción", "Imagen3", "Actores3", 4, 8.5));
            res.Add(new Movie("Lo que el Viento se llevó", "1995", "Drama", "Imagen3", "Actores3", 27, 9.83));
            res.Add(new Movie("Invictus", "1995", "Drama", "Imagen3", "Actores3", 18, 7.5));
            res.Add(new Movie("Gol II", "2003", "Deporte", "Imagen3", "Actores3", 12, 3.2));
            res.Add(new Movie("Star Wars: Una nueva Esperanza", "1977", "Drama", "Imagen3", "Actores7", 7, 8.12));
            return res;
        }
    }
}
