﻿using MovieMockFrame.model;
using MovieMockFrame.view;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieMockFrame.app
{
    class MockPanel : MoviesDisplay
    {
        private MovieData movieData;

        public MockPanel() {
            this.execute();    
        }

        private void execute()
        {
            //Graphical Assets
        }

        public void display(MovieData movieData)
        {
            this.movieData = movieData;
        }

        public void Change() {
            Console.WriteLine("LISTA ACTUAL");
            Console.WriteLine(this.movieData.ToString());
        }
    }
}
