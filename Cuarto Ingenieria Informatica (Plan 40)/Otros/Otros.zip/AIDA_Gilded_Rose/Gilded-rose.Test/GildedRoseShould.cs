using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Gilded_rose;
using NUnit.Framework;

namespace KataGildedRose.Tests
{
    public class GildedRoseTest
    {

        [TestCase("Normal item", 0, 2, 0)]
        [TestCase("Normal item", 1, 2, 1)]
        [TestCase("Normal item", 0, 1, 0)]
        [TestCase("Normal item", 0, 0, 0)]
        public void decrease_quality_of_items_depending_on_sellIn(string name, int sellIn, int quality, int expected)
        {
            IList<Item> Items = new List<Item> { new Item { Name = name, SellIn = sellIn, Quality = quality } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().SellIn.Should().Be(sellIn-1);
            Items.First().Quality.Should().Be(expected);
        }

        [Test]
        public void not_decrease_quality_of_an_item_if_it_is_legendary()
        {
            IList<Item> Items = new List<Item> { new Item { Name = "Sulfuras, Hand of Ragnaros", SellIn = 0, Quality = 80 } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().SellIn.Should().Be(0);
            Items.First().Quality.Should().Be(80);
        }

        [TestCase("Aged Brie",1,20,21)]
        [TestCase("Aged Brie",0,20,22)]
        [TestCase("Aged Brie",0,49,50)]
        [TestCase("Aged Brie", 1, 50, 50)]
        [TestCase("Aged Brie", -1, 49, 50)]
        public void increase_quality_of_aged_brie(string name, int sellIn, int quality, int expected)
        {
            IList<Item> Items = new List<Item> { new Item { Name = name, SellIn = sellIn, Quality = quality } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().SellIn.Should().Be(sellIn - 1);
            Items.First().Quality.Should().Be(expected);
        }
        
        [Test]
        public void increase_quality_of_backstage()
        {
            IList<Item> Items = new List<Item> { new Item { Name = "Backstage passes to a TAFKAL80ETC concert", SellIn = 11, Quality = 30 } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().Quality.Should().Be(31);
        }

        [Test]
        public void increase_quality_of_backstage_twice_as_fast_when_sellIn_is_between_10_and_5()
        {
            IList<Item> Items = new List<Item> { new Item { Name = "Backstage passes to a TAFKAL80ETC concert", SellIn = 10, Quality = 30 } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().Quality.Should().Be(32);
        }

        [Test]
        public void increase_quality_of_backstage_thrice_as_fast_when_sellIn_is_between_5_and_0()
        {
            IList<Item> Items = new List<Item> { new Item { Name = "Backstage passes to a TAFKAL80ETC concert", SellIn = 5, Quality = 30 } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().Quality.Should().Be(33);
        }

        [Test]
        public void drop_quality_to_zero_if_sellin_has_passed()
        {
            IList<Item> Items = new List<Item> { new Item { Name = "Backstage passes to a TAFKAL80ETC concert", SellIn = 0, Quality = 30 } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().Quality.Should().Be(0);
        }

        [TestCase("Conjured", 1, 30, 28)]
        [TestCase("Conjured", 1, 5, 3)]
        [TestCase("Conjured", -1, 30, 26)]
        [TestCase("Conjured", -1, 3, 0)]
        [TestCase("Conjured", 0, 30, 26)]
        [TestCase("Conjured", 0, 3, 0)]
        public void decrease_when_item_is_conjured(string name, int sellIn, int quality, int expected)
        {
            IList<Item> Items = new List<Item> { new Item { Name = name, SellIn = sellIn, Quality = quality } };
            var app = new GildedRose(Items);

            app.UpdateQuality();

            Items.First().SellIn.Should().Be(sellIn-1);
            Items.First().Quality.Should().Be(expected);
        }

    }
}