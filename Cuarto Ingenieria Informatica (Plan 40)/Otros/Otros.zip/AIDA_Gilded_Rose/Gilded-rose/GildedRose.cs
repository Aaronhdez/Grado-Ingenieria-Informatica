﻿using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using Gilded_rose.ItemsFolder;

namespace Gilded_rose
{
    public class GildedRose
    {
        private readonly ItemsFactory _itemsFactory = ItemsFactory.Instance;
        public IList<Item> Items;

        public GildedRose(IList<Item> Items)
        {
            this.Items = Items;
        }

        public void UpdateQuality()
        {
            foreach (var item in Items)
            {
                item.Quality = _itemsFactory.GetInstanceFromExistentItem(item).GetUpdatedQuality();
                item.SellIn = _itemsFactory.GetInstanceFromExistentItem(item).GetUpdatedSellIn();
            }
        }
        
    }

    public class Item
    {
        public string Name { get; set; }
        public int SellIn { get; set; }
        public int Quality { get; set; }
    }
}