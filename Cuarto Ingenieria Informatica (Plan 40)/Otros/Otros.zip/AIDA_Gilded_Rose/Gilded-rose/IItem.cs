﻿namespace Gilded_rose
{
    public interface IItem
    {
        int GetUpdatedQuality();
        int GetUpdatedSellIn();
    }
}