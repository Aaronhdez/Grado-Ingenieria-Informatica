﻿namespace Gilded_rose.ItemsFolder
{
    public class RegularItem : IItem
    {
        public RegularItem(int quality, int sellIn)
        {
            Quality = quality;
            SellIn = sellIn;
        }

        public string Name { get; set; }
        public int SellIn { get; set; }
        public int Quality { get; set; }
        private void UpdateQuality()
        { 
            if(SellIn > 0)
                Quality -= (Quality >= 1) ? 1 : 0;
            
            if(SellIn == 0) {
                Quality -= (Quality >= 2) ? 1 : 0;
                Quality -= (Quality >= 1) ? 1 : 0;
            }
            
            if (SellIn < 0)
                Quality -= (Quality > 1) ? 2 : 0;
        }

        private void UpdateSellIn()
        {
            SellIn--;
        }

        public int GetUpdatedQuality()
        {
            UpdateQuality();
            return Quality;
        }

        public int GetUpdatedSellIn()
        {
            UpdateSellIn();
            return SellIn;
        }
    }
}