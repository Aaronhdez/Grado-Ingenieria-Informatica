﻿using System;

namespace Gilded_rose.ItemsFolder
{
    class ConjuredItem : Item, IItem
    {
        public ConjuredItem(int quality, int sellIn)
        {
            Quality = quality;
            SellIn = sellIn;
        }

        private void UpdateQuality()
        {
            if (SellIn > 0)
            {
                Quality -= (Quality == 1) ? 1 : 0;
                Quality -= (Quality >= 2) ? 2 : 0;
            }
            else
            {
                Quality -= (Quality < 4) ? Quality : 0;
                Quality -= (Quality >= 4) ? 4 : 0;
            }
        }

        private void UpdateSellIn()
        {
            SellIn--;
        }

        public int GetUpdatedQuality()
        {
            UpdateQuality();
            return Quality;
        }

        public int GetUpdatedSellIn()
        {
            UpdateSellIn();
            return SellIn;
        }
    }
}