#include "mn_aritmeticas.h"

#ifndef MN_CALCULO_CEROS_H
#define MN_CALCULO_CEROS_H


// PROTOTIPOS FUNCIONES PARA CALCULAR CEROS EN UNA FUNCION
real interes();


#endif
