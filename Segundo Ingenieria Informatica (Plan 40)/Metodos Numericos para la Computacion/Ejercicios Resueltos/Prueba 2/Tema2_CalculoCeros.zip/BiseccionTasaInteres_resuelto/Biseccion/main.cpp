#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
using namespace std;
#include "../mn_calculo_ceros.h"

int main()
{
    /// CALCULO TASA DE INTERES A 3 A�OS
    printf("tasa interes aplicado :   (real) =%lf\n",0.032618);
    printf("tasa interes aplicado : (alumno) =%lf\n",interes());



    system ("pause");
}

