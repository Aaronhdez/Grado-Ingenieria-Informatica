#include "mn_aritmeticas.h"

#ifndef MN_CALCULO_CEROS_H
#define MN_CALCULO_CEROS_H


// PROTOTIPOS FUNCIONES PARA CALCULAR CEROS EN UNA FUNCION
real mn_biseccion (real (*f)(const real), real &a, real &b, const real TOL,int &error);


#endif
