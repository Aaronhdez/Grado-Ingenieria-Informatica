int mi_strlen (char* str);
char* mi_strcpy (char* s1, char* s2);
char* mi_strcat (char* s1, char* s2);
char* mistrdup (char* str);
int mi_strequals (char* s1, char* s2);
