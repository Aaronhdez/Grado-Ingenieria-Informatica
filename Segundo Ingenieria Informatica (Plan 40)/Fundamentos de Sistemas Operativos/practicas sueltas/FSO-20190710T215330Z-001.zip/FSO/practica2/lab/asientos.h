int find(int dni);

int clear(int pos);

int test(int pos);

int numClear();

int numSet();

void inicialice();
