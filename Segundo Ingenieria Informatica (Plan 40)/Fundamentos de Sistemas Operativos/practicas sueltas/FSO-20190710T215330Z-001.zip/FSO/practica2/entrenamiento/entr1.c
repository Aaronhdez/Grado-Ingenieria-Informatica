#include <stdio.h>

main() {
	// Mi primer programa en C

	printf("Hola mundo \n");
}
