package videoteca.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GenresListDlg extends JDialog {
    // Listener que realiza la muestra 
    private ActionListener okHandler= new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent arg0) {
        }
    };
}