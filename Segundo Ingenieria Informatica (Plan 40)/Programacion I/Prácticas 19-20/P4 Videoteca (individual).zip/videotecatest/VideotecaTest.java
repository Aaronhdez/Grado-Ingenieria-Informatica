package videotecatest;

import org.junit.*;
import static org.junit.Assert.*;

public class VideotecaTest {

    //Escriba aquí los tests
    @Test
    public void test1(){
        
    }
}
