package videoteca.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GenresListDlg extends JDialog {

}