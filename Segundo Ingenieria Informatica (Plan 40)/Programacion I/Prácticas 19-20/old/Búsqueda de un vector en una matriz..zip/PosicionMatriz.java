public class PosicionMatriz {
    
    /* 
    *  --------------------------------------
    *   ATRIBUTOS
    *  --------------------------------------
    */
    private int row;
    private int column;
    
    /* 
    *  --------------------------------------
    *   CONSTRUCTORES
    *  --------------------------------------
    */
    public PosicionMatriz() {
        row = 0;
        column = 0;
    }
    
    public PosicionMatriz(int inrow, int incol) {
        row = inrow;
        column = incol;
    }
    
    /* 
    *  --------------------------------------
    *   METODOS INHERENTES
    *  --------------------------------------
    */
    
    /** Metodo DameColumna()
     *  
     * Retorna el valor de la Columna.
     * @return  int Retorna el valor del atributo.
     **/
    public int dameColumna(){
        return column;
    }
    
    /** Metodo DameFila()  
     * 
     * Retorna el valor de la fila.
     * @return  int Retorna el valor del atributo fila.
     **/
    public int dameFila(){
        return row;
    }

    /* 
    *  --------------------------------------
    *   METODOS GENERALES
    *  --------------------------------------
    */
    
    /** Metodo toString()  
     * 
     * Devuelve una string correspondiente a los atributos
     * del objeto caller.
     * 
     * @return  String  Retorna los atributos como string.
     **/
    @Override
    public String toString(){
        return "["+row+"]["+column+"]";
    }
    
    /** Metodo toString()  
     * 
     * Revisa si ambos objetos son:
     * 1: Del mismo tipo (PosicionMatriz);
     * 2: Equivalentes en sus atibutos.
     * 
     * @param   Object  Requiere de un objeto.
     * @return  Boolean Retorna true si son equivalentes.
     **/
    @Override
    public boolean equals(Object arg0){
        if(arg0 instanceof PosicionMatriz){
            PosicionMatriz input = (PosicionMatriz)arg0;
            if(row == input.row && column == input.column){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
}