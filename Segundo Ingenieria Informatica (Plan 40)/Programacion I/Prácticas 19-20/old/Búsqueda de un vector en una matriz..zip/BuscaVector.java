public class BuscaVector {
    
    public static void main(String[] args) {
        int[][] m = {{0,2,3,4,5,6,7,8},{1,2,5,6,7,8},{1,2,3,7,8},{1,6,7,8,8,8,10}};
        int[]   v = {8,10};
        PosicionMatriz res = buscaVectorEnMatriz(m,v);
        if(res == null){
            System.out.println("Vector no encontrado");
        }else{
            System.out.println("El vector se ha encontrado en la posición " + res);
        }
        
        int[][] m2 = {{1,2,3,4,5,6,7,8},{1,2,5,6,7,8},{1,2,3,7,8},{1,6,7,8}};
        int[]   v2 = {3,7,8};
        PosicionMatriz res2 = buscaVectorEnMatriz(m2,v2);
        if(res2 == null){
            System.out.println("Vector no encontrado");
        }else{
            System.out.println("El vector se ha encontrado en la posición " + res2);
        }
    }
    
    public static PosicionMatriz buscaVectorEnMatriz(int[][] m, int[] v){
        if(v.length ==0 || m.length == 0){
            return null;
        }
        //Desarrollo metodo
        for(int i=0; i<m.length; i++){
            for(int j=0; j<m[i].length; j++){
                if(m[i][j] == v[0] && (m[i].length-j) >= v.length){
                    boolean status = checkStatus(j, i, m, v);
                    if(status){
                        PosicionMatriz res = new PosicionMatriz(i,j);
                        return res;
                    }
                }
            }
        }
        return null;
    }
    private static boolean checkStatus(int j, int i, int[][] m, int[] v){
        for(int k=0; k<v.length; k++, j++){
            if(m[i][j] != v[k]){
                return false;
            }
        }
        return true; 
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    