import java.util.*;

public class UsaDocumentos{
    public static void main (String[] args) {
        
        org.junit.runner.JUnitCore.main("ComponentesTest");
//        ComponenteTexto t1 = new ComponenteTexto(" hola,jeje   como estas +  ");
//        ComponenteTexto t2 = new ComponenteTexto("\n");
//        ComponenteTexto t3 = new ComponenteTexto(" ");
//        ComponenteTexto t4 = new ComponenteTexto("");
//        ComponenteTexto t5 = new ComponenteTexto(" \n    o op ");
//        ComponenteNumero n1 = new ComponenteNumero(345);
//        ComponenteNumero n2 = new ComponenteNumero(350);
//        ComponenteNumero n3 = new ComponenteNumero(123);
//        ComponenteFecha f1 = new ComponenteFecha(new Date());
//        Componente c1 = new ComponenteNumero(2);
//        
//        ComponenteCompuesto cc1 = new ComponenteCompuesto();
//        ComponenteCompuesto cc2 = (ComponenteCompuesto)cc1.copia();
//        System.out.println("---------Pruebas---------");
//        
//        System.out.println("Numero de palabras t1: "+t1.nPalabras());
//        System.out.println("Numero de caracteres t1: "+t1.nCaracteres());
//        System.out.println("Numero de palabras t2: "+t2.nPalabras());
//        System.out.println("Numero de caracteres t2: "+t2.nCaracteres());
//        System.out.println("Numero de palabras t3: "+t3.nPalabras());
//        System.out.println("Numero de caracteres t3: "+t3.nCaracteres());
//        System.out.println("Numero de palabras t4: "+t4.nPalabras());
//        System.out.println("Numero de caracteres t4: "+t4.nCaracteres());
//        System.out.println("Numero de palabras t5: "+t5.nPalabras());
//        System.out.println("Numero de caracteres t5: "+t5.nCaracteres());
//        System.out.println("Numero de palabras n1: "+n1.nPalabras());
//        System.out.println("Numero de caracteres n1: "+n1.nCaracteres());
//        System.out.println("---------Pruebas---------");
//        
//         long segundosDía = 60 * 60 * 24;
//         ComponenteCompuesto d, p;
//         Date hoy = new Date();
//         p = new ComponenteCompuesto();
//         p.añade(new ComponenteTexto("Ristra "));
//         p.añade(new ComponenteNumero(1));
//         p.añade(new ComponenteTexto("\n"));
//         p.añade(new ComponenteTexto("Fecha de hoy "));
//         p.añade(new ComponenteFecha(hoy));
//         p.añade(new ComponenteTexto("\n"));
//         p.añade(new ComponenteTexto("Fecha de ayer "));
//         p.añade(new ComponenteFecha(new Date(hoy.getTime() - segundosDía*1000)));
//         p.añade(new ComponenteTexto("\n"));
//         p.añade(new ComponenteTexto("Fecha de hace 30 días ("));
//         p.añade(new ComponenteNumero(86400 * 30));
//         p.añade(new ComponenteTexto(" seg) "));
//         p.añade(new ComponenteFecha( new Date(hoy.getTime() - (segundosDía * 30*1000))));
//         p.añade(new ComponenteTexto("\n"));
//         d = new ComponenteCompuesto();//23
//         d.añade(new ComponenteTexto("Componente de prueba"));
//         d.añade(new ComponenteTexto("\n"));
//         d.añade(p);
//         d.añade(new ComponenteTexto("Fin componente de prueba"));
//         System.out.println(d);
//         System.out.println("Número de caracteres " + d.nCaracteres());
//         System.out.println("Número de palabras " + d.nPalabras());
//         d.modifica(0, new ComponenteTexto("Inicio modificado"));
//         System.out.println(d);
//         System.out.println("Número de caracteres " + d.nCaracteres());
//         System.out.println("Número de palabras " + d.nPalabras());
//         System.out.println("PROBANDO COSAS");
//         d.añade(d);
//         System.out.println(d.nPalabras());
//         d.añade(d);
//         System.out.println(d.nPalabras());
    }
    
}






