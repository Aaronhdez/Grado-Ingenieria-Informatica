

public class UsaConjunto{
    public static void main (String[] args) {
        org.junit.runner.JUnitCore.main("ConjuntoTest"); 
        System.out.println("hola");
    }
}