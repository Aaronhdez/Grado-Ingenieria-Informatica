//Función de arranque 
document.addEventListener("DOMContentLoaded", function() {
    //Eleccionamos la accion correspondiente, que en este caso es un submit
    document.getElementById("formulario").addEventListener('submit', checkInput); 
});

//Una vez se pulsa el envío, el evento toma lugar.
//Como es un tipo submit, debemos prevenir que ocurra, para ello colocamos la sentencia
//PreventDefault
function checkInput(evento){
    evento.preventDefault();
    var name = document.getElementById('nameSurname').value;
    var place = document.getElementById('place').value;
    var city = document.getElementById('city').value;
    var cp = document.getElementById('cp').value;
    var cardInfo = document.getElementById('cardInfo').value;
    var cvv2 = document.getElementById('cvv2').value;
   
    var errors = false;
    var errorTxt = "";
    var errorMsg = document.getElementById('errorMsg');
    errorMsg.innerHTML = "";
    
    if(name.length < 1){
        errors = true;
        errorTxt = errorTxt + "<li>Debe especificar un nombre</li>";
    }
    if(city.length < 1){
        errors = true;
        errorTxt = errorTxt + "<li>Dirección no especificada (Ciudad)</li>";
    }  
    if(place.length < 1){
        errors = true;
        errorTxt = errorTxt + "<li>Dirección no especificada (Provincia)</li>";
    }  
    
    if(!cp.match("([0-9]{5})$")){
        errors = true;
        errorTxt = errorTxt + "<li>Codigo Postal erróneo</li>";
    }  
    if(cardInfo.length < 16){
        errors = true;
        errorTxt = errorTxt + "<li>Información de tarjeta incorrecta</li>";
    }
    if(cvv2.length < 1){
        errors = true;
        errorTxt = errorTxt + "<li>Proporcione el código CVV2 asociado a su tarjeta</li>";
    }  
    
    if(errors){
        errorMsg.style.color = "red";
        errorMsg.innerHTML = "<ul>" + errorTxt + "</ul>"
        errors = false;
        return;
    }
    
    this.submit();
}
