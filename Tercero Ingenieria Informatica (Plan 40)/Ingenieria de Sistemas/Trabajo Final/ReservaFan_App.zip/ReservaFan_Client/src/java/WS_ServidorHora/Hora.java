/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS_ServidorHora;

/**
 *
 * @author Lab-DIS
 */
public class Hora {
    private String Hora;

    public Hora(String hora) {
        this.Hora = hora;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        this.Hora = hora;
    }
}
