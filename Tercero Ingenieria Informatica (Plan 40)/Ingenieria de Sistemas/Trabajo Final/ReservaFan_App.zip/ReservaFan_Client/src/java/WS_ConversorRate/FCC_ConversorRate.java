/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS_ConversorRate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

/**
 *
 * @author Lab-DIS
 */
public class FCC_ConversorRate {
    public static double convert(String to) throws IOException{
        try {
            URL url = new URL("http://free.currconv.com/api/v7/convert?q=EUR"
                    + "_" + to + "&compact=ultra&apiKey=8e5a85e334f6d4896d03");
            URLConnection connection = url.openConnection();
            BufferedReader reader = new BufferedReader( new InputStreamReader(connection.getInputStream()));
            String line = reader.readLine();
            System.out.println(line);
            String line1 = line.substring(line.indexOf(":")+1, line.indexOf("}"));
            System.out.println(line1);
            return Double.parseDouble(line1);
        }   catch (IOException |  NumberFormatException ex) {
        }   finally {
        
        }
        return 0;
    }
}
