/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

public class Reservas {

    private String token;
    private String nombre;
    private String domicilio;
    private String nTarjetayCVS;
    private String fechaPartido;
    private int nentradas;
    private String total;
    private Usuarios cuentaAsociada;

    public Reservas() {
    }

    public Reservas(String token) {
        this.token = token;
    }

    public Reservas(String token, String nombre, String domicilio, String nTarjetayCVS, String fechaPartido, int nentradas, String total) {
        this.token = token;
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.nTarjetayCVS = nTarjetayCVS;
        this.fechaPartido = fechaPartido;
        this.nentradas = nentradas;
        this.total = total;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getNTarjetayCVS() {
        return nTarjetayCVS;
    }

    public void setNTarjetayCVS(String nTarjetayCVS) {
        this.nTarjetayCVS = nTarjetayCVS;
    }

    public String getFechaPartido() {
        return fechaPartido;
    }

    public void setFechaPartido(String fechaPartido) {
        this.fechaPartido = fechaPartido;
    }

    public int getNentradas() {
        return nentradas;
    }

    public void setNentradas(int nentradas) {
        this.nentradas = nentradas;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Usuarios getCuentaAsociada() {
        return cuentaAsociada;
    }

    public void setCuentaAsociada(Usuarios cuentaAsociada) {
        this.cuentaAsociada = cuentaAsociada;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (token != null ? token.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservas)) {
            return false;
        }
        Reservas other = (Reservas) object;
        if ((this.token == null && other.token != null) || (this.token != null && !this.token.equals(other.token))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bd.Reservas[ token=" + token + " ]";
    }
    
}
