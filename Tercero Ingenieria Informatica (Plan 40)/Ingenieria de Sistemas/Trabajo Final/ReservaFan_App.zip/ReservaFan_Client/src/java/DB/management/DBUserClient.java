/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB.management;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

/**
 * Jersey REST client generated for REST resource:we [bd.usuarios/{cuenta}]<br>
 * USAGE:
 * <pre>
 *        DBUserClient client = new DBUserClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author Lab-DIS
 */
public class DBUserClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://ws.docencia.ces.siani.es/a14/BD_ReservaFan/webresources/";

    public DBUserClient(String cuenta) {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        String resourcePath = java.text.MessageFormat.format("bd.usuarios/{0}", new Object[]{cuenta});
        webTarget = client.target(BASE_URI).path(resourcePath);
    }

    public void setResourcePath(String cuenta) {
        String resourcePath = java.text.MessageFormat.format("bd.usuarios/{0}", new Object[]{cuenta});
        webTarget = client.target(BASE_URI).path(resourcePath);
    }

    /**
     * @param responseType Class representing the response
     * @return response object (instance of responseType class)
     */
    public <T> T findUser(Class<T> responseType) throws ClientErrorException {
        return webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_JSON).get(responseType);
    }

    public void close() {
        client.close();
    }
    
}
