/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Booking;

import DB.management.DBBookingCreator;
import Internal_WS.SOAP.WSPriceCalculator_Service;
import DB.Reservas;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.ClientErrorException;
import javax.xml.ws.WebServiceRef;
import Utilities.SingletonAccount;
import javax.servlet.RequestDispatcher;
import ws.NoSuchAlgorithmException_Exception;
import ws.WSHash;

/**
 *
 * @author Lab-DIS
 */
@WebServlet(name = "BookingCreate", urlPatterns = {"/BookingCreate"})
public class BookingCreate extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/ws.docencia.ces.siani.es/a16/SOAP_Impuestos/WS_PriceCalculator.wsdl")
    private WSPriceCalculator_Service service_1;

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/ws.docencia.ces.siani.es/a16/SOAP_TokenGenerator/WS_Hash.wsdl")
    private WSHash service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
            request.getContextPath();
            // --> SOAP propio PRICECALCULATOR -> WITHOUTVAT
            // CALCULAR TOTAL 
            String pricePerTicket = request.getParameter("pricePerTicket");
            String ntickets = request.getParameter("nTickets");
            int nentradas = Integer.parseInt(ntickets);
            
            //--> SOAP propio PRICECALCULATOR -> WITHVAT
            // CALCULAR TOTAL + IMPUESTOS 
            String tax = request.getParameter("vat");
            int percentage = Integer.parseInt(tax);
            long withoutTaxes = Long.parseLong(priceWithoutTaxes(Long.parseLong(pricePerTicket), nentradas));
            String total = priceWithTaxes(withoutTaxes,percentage);
            
            // PREPARAR DATOSPAGO
            String cardInfo = request.getParameter("cardInfo");
            String cvv2 = request.getParameter("cvv2");
            String nTarjetayCVS = cardInfo+cvv2;
            
            // --> SOAP propio TOKENGENERATOR
            // HASHEAR FECHA ACTUAL + FECHAPARTIDO + CUENTA + DATOSPAGO
            String fechaPartido = request.getParameter("fechaPartido");
            String token = "";
            try {
                token = bookingTokenGenerator(fechaPartido+ 
                        SingletonAccount.getCurrentInstance().getCuenta()+
                        nTarjetayCVS);
            } catch (NoSuchAlgorithmException_Exception ex) {
                Logger.getLogger(BookingCreate.class.getName()).log(Level.SEVERE, null, ex);
            }
            //RECUPERAR DATOS RESTANTES
            String nombre = request.getParameter("nameSurname");
            String calle = request.getParameter("place");
            String ciudad = request.getParameter("city");
            String cp = request.getParameter("city");
            String domicilio = calle + ", CP:" + cp + ", " + ciudad;
            
            //INSTANCIAR RESERVA 
            SingletonAccount.getCurrentInstance().setReservasCollection(null);
            Reservas nuevaReserva = new Reservas(token, nombre, domicilio, nTarjetayCVS, fechaPartido, nentradas, total);
            nuevaReserva.setCuentaAsociada(SingletonAccount.getCurrentInstance());
            DBBookingCreator bookingCreator = new DBBookingCreator();
            try{
                bookingCreator.create_JSON(nuevaReserva);
                RequestDispatcher view = request.getRequestDispatcher("Success");
                view.forward(request, response);
            } catch(ClientErrorException cee){
                RequestDispatcher view = request.getRequestDispatcher("Fail");
                view.forward(request, response);
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String bookingTokenGenerator(java.lang.String password) throws NoSuchAlgorithmException_Exception {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        ws.WSTokenGenerator port = service.getWSTokenGeneratorPort();
        return port.bookingTokenGenerator(password);
    }

    private String priceWithTaxes(long totalPriceWithoutTaxes, int vat) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        Internal_WS.SOAP.WSPriceCalculator port = service_1.getWSPriceCalculatorPort();
        return port.priceWithTaxes(totalPriceWithoutTaxes, vat);
    }

    private String priceWithoutTaxes(long unitaryPrice, int numberOfTickets) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        Internal_WS.SOAP.WSPriceCalculator port = service_1.getWSPriceCalculatorPort();
        return port.priceWithoutTaxes(unitaryPrice, numberOfTickets);
    }

}
