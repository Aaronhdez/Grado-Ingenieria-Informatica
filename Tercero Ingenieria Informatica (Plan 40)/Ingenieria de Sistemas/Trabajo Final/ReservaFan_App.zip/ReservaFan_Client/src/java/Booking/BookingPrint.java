/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Booking;

import DB.Reservas;
import DB.management.DBBookingFinder;
import Internal_WS.SOAP.WSPriceCalculator_Service;
import Utilities.ProjectUtils;
import WS_ConversorRate.FCC_ConversorRate;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebServiceRef;
import ws.WSConversor_Service;

/**
 *
 * @author Lab-DIS
 */
@WebServlet(name = "BookingPrint", urlPatterns = {"/BookingPrint"})
public class BookingPrint extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/ws.docencia.ces.siani.es/a16/SOAP_Conversor/WS_Conversor.wsdl")
    private WSConversor_Service service;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet bookingPrint</title>");    
            out.println("<link rel='stylesheet' href='./printMode.css'>");        
            out.println("</head>");
            out.println("<body>");
            out.println("<script src='./printBill.js'></script>");
            out.println(ProjectUtils.getNavBar());
            DBBookingFinder localizador = new DBBookingFinder(request.getParameter("id"));
            Reservas current = localizador.find_JSON(Reservas.class);
            double ratio = FCC_ConversorRate.convert(request.getParameter("currency"));
            double from = Double.parseDouble(current.getTotal());
            String price = convertMoney(from, ratio);
            out.println("<div class='booking'>");
            out.println("<div class='innerForm'>");
            out.println("<div class='inner'>"); 
            out.println("<ul>" +
                        "<h2>Datos de la Reserva</h2>" +
                        "<li><b>Fecha del partido: </b>" + current.getFechaPartido() + "</li>" +
                        "<li><b>ID de la Reserva: </b>" + current.getToken() + "</li>" +
                        "<li><b>Usuario asociado: </b>" + current.getCuentaAsociada().getCuenta() + "</li>"+
                        "<li><b>Nombre del Titular: </b>" + current.getNombre()+ "</li>"+
                        "<li><b>Entradas: </b>" +current.getNentradas() + "</li>");
            if(request.getParameter("currency").equals("GBP")){
                out.println( "<li><b>Total: </b>" + price + " Libras</li>");
            }
            if(request.getParameter("currency").equals("EUR")){
                out.println( "<li><b>Total: </b>" + price + " Euros</li>");
            }
            if(request.getParameter("currency").equals("USD")){
                out.println( "<li><b>Total: </b>" + price + " Dolares</li>");
            }
            out.println("<li><b>Datos del Faturación: </b>" + current.getNTarjetayCVS().substring(0, current.getNTarjetayCVS().length()-3) + "</li>" +
                        "</ul>");
            out.println("</div>");
            out.println("<div class='innerButton'>");
            out.println("<button onclick='printDoc()'>Imprimir</button>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String convertMoney(double from, double conversorRate) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        ws.WSConversor port = service.getWSConversorPort();
        return port.convertMoney(from, conversorRate);
    }

    
}
