/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Booking;

import Utilities.ProjectUtils;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Utilities.SingletonAccount;

/**
 *
 * @author Lab-DIS
 */
@WebServlet(name = "BookingServlet", urlPatterns = {"/BookingServlet"})
public class BookingServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>TODO supply a title</title>");
            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<link rel='stylesheet' href='./bookingForm.css'>");
            out.println("<link rel='stylesheet' href='./style.css'>");
            out.println("</head>");
            out.println("<body>");
            out.println("<script src='formChecker.js'></script>");
            out.println(ProjectUtils.getNavBar());
            out.println("<main>");
            out.println("<div class='bookingMain'>");
            out.println("<div class='bookingFormArea'>");
            out.println("<form id='formulario' method='post' action='./BookingCreate'>");
            out.println("<div class='bookingFormRowText'><h3>Información de la Reserva</h3></div>");
            out.println("<div class='bookingFormRowText'><b>Datos de Facturación</b></div>");
            out.println("<div class='bookingFormRow'><input placeholder='Nombre y Apellidos' type='text' id='nameSurname' name='nameSurname'></div>");
            out.println("<div class='bookingFormRow'><input placeholder='Domicilio' type='text' id='place' name='place'></div>");
            out.println("<div class='bookingFormRow'>"
                        + "<div class='doubleInput' ><input placeholder='Ciudad' type='text' id='city' name='city'>"
                        + "<input placeholder='Codigo Postal' type='text' id='cp' name='cp'></div>"
                        + "</div>");
            out.println("<div class='bookingFormRowText'><b>Datos de Pago</b></div>");
            out.println("<div class='bookingFormRow'>"
                        + "<div class='doubleInput'><input placeholder='XXXX XXXX XXXX XXXX' id='cardInfo' type='text' name='cardInfo'>"
                        + "<input placeholder=CVV2 type='password' name='cvv2' id='cvv2'></div>"
                        + "</div>");
            out.println("<div class='bookingFormRow'>"
                        + "<input type='radio' id='vat1' name='vat' value='7' checked>"
                        + "<label for='vat1'>Residente Canario (7%)</label><br>"
                        + "<input type='radio' id='vat2' name='vat' value='21'>"
                        + "<label for='vat2'>Península (21%)</label><br>"
                        + "</div>");
            out.println("<div class='bookingFormRowText'><b>Entradas Solicitadas</b></div>");
            out.println("<div class='bookingFormRow'>"
                        + "<div class='doubleInput'>"
                        + "<select name='nTickets'>"
                        + "<option value='2' selected>2</option>"
                        + "<option value='3'>3</option>"
                        + "<option value='4'>4</option>"
                        + "</select>"
                        + "<select name='pricePerTicket'>"
                        + "<option value='15' selected>Joven: 15€</option>"
                        + "<option value='25'>Animación: 25€</option>"
                        + "<option value='35'>Regular: 35€</option>"
                        + "<option value='70'>VIP: 70€</option>"
                        + "<option value='100'>Deluxe: 100€</option>"
                        + "</select>"
                        + "</div>"
                        + "</div>");
            out.println("<div class='bookingFormRow'>"
                        + "<input type='submit' value='Confirmar Reserva'>"
                        + "<input type='hidden' value='"+request.getParameter("date")+"' name='fechaPartido'>"
                        + "</div>");
            out.println("<div class='bookingFormRow'>"
                        +"<input type='submit' value='Volver' formaction='./ListOfMatches' method='GET'>"
                        +"<input type='hidden' value="+request.getParameter("leaguesaison")+" name='leaguesaison'>"
                        +"<input type='hidden' value="+request.getParameter("idleague")+" name='idleague'>"
                        +"<input type='hidden' value="+request.getParameter("leagueID")+" name='leagueID'>"      
                        +"<input type='hidden' value="+request.getParameter("jornada")+" name='jornada'>"   
                        + "</div>");
            out.println("</form>");
            out.println("</div>");
            out.println("<div class='bookingFormAreaData'>");
            out.println("<div>");
            out.println("<h3>Partido Seleccionado</h3>");
            
            out.println("<div class='bookingFormRow'>"+request.getParameter("league")+"</div>");
            out.println("<div class='bookingFormRow'><b>"+request.getParameter("team1")+" - "+request.getParameter("team2")+"</b></div>");
            out.println("<div class='bookingFormRow'>"+request.getParameter("date")+"</div>");
            out.println("<div class='bookingFormRow'></div>");
            out.println("<div class='bookingFormRowInfo'>"
                    + "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
                    + "Aenean scelerisque sagittis metus, et malesuada nulla posuere sit amet. "
                    + "Phasellus sagittis mauris lacus, eu pretium mauris semper id. Maecenas ac metus mi. </p>"
                    + "<p>Nulla facilisi. Pellentesque vitae diam eget mi efficitur porttitor. "
                    + "Ut pharetra ipsum dapibus ligula porta, id accumsan lacus posuere. "
                    + "Vivamus id pellentesque justo. Nulla eu lacus condimentum mi fermentum porta id et elit.</p>");
            out.println("</div>");
            out.println("<div class='bookingFormRowInfo'>");
            out.println("<div class='errorMsg' id='errorMsg'></div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</main>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
