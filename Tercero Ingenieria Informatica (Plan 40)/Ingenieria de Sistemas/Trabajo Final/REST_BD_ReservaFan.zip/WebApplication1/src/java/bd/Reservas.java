/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lab-DIS
 */
@Entity
@Table(name = "reservas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reservas.findAll", query = "SELECT r FROM Reservas r")
    , @NamedQuery(name = "Reservas.findByToken", query = "SELECT r FROM Reservas r WHERE r.token = :token")
    , @NamedQuery(name = "Reservas.findByNombre", query = "SELECT r FROM Reservas r WHERE r.nombre = :nombre")
    , @NamedQuery(name = "Reservas.findByDomicilio", query = "SELECT r FROM Reservas r WHERE r.domicilio = :domicilio")
    , @NamedQuery(name = "Reservas.findByNTarjetayCVS", query = "SELECT r FROM Reservas r WHERE r.nTarjetayCVS = :nTarjetayCVS")
    , @NamedQuery(name = "Reservas.findByFechaPartido", query = "SELECT r FROM Reservas r WHERE r.fechaPartido = :fechaPartido")
    , @NamedQuery(name = "Reservas.findByNentradas", query = "SELECT r FROM Reservas r WHERE r.nentradas = :nentradas")
    , @NamedQuery(name = "Reservas.findByTotal", query = "SELECT r FROM Reservas r WHERE r.total = :total")})
public class Reservas implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "token")
    private String token;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "Domicilio")
    private String domicilio;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "NTarjeta_y_CVS")
    private String nTarjetayCVS;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "FechaPartido")
    private String fechaPartido;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Nentradas")
    private int nentradas;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "total")
    private String total;
    @JoinColumn(name = "cuenta_asociada", referencedColumnName = "cuenta")
    @ManyToOne(optional = false)
    private Usuarios cuentaAsociada;

    public Reservas() {
    }

    public Reservas(String token) {
        this.token = token;
    }

    public Reservas(String token, String nombre, String domicilio, String nTarjetayCVS, String fechaPartido, int nentradas, String total) {
        this.token = token;
        this.nombre = nombre;
        this.domicilio = domicilio;
        this.nTarjetayCVS = nTarjetayCVS;
        this.fechaPartido = fechaPartido;
        this.nentradas = nentradas;
        this.total = total;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getNTarjetayCVS() {
        return nTarjetayCVS;
    }

    public void setNTarjetayCVS(String nTarjetayCVS) {
        this.nTarjetayCVS = nTarjetayCVS;
    }

    public String getFechaPartido() {
        return fechaPartido;
    }

    public void setFechaPartido(String fechaPartido) {
        this.fechaPartido = fechaPartido;
    }

    public int getNentradas() {
        return nentradas;
    }

    public void setNentradas(int nentradas) {
        this.nentradas = nentradas;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Usuarios getCuentaAsociada() {
        return cuentaAsociada;
    }

    public void setCuentaAsociada(Usuarios cuentaAsociada) {
        this.cuentaAsociada = cuentaAsociada;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (token != null ? token.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reservas)) {
            return false;
        }
        Reservas other = (Reservas) object;
        if ((this.token == null && other.token != null) || (this.token != null && !this.token.equals(other.token))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "bd.Reservas[ token=" + token + " ]";
    }
    
}
