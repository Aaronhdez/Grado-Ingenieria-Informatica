/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author Lab-DIS
 */
@WebService(serviceName = "WS_Hash")
public class WS_TokenGenerator {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "bookingTokenGenerator")
    public String bookingTokenGenerator(@WebParam(name = "password") String password) throws NoSuchAlgorithmException {
                MessageDigest md = MessageDigest.getInstance("MD5");
                md.update(password.getBytes());
                byte[] digest = md.digest();
                //Comparamos las claves existentes
                return DatatypeConverter.printHexBinary(digest).toUpperCase();
    }
}
