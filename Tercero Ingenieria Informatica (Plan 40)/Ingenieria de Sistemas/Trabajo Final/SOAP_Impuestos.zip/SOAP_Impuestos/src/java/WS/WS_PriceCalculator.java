/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Lab-DIS
 */
@WebService(serviceName = "WS_PriceCalculator")
public class WS_PriceCalculator {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "priceWithoutTaxes")
    public String priceWithoutTaxes(@WebParam(name = "unitaryPrice") long unitaryPrice, @WebParam(name = "numberOfTickets") int numberOfTickets) {
        //TODO write your implementation code here:
        return Long.toString(unitaryPrice*numberOfTickets);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "priceWithTaxes")
    public String priceWithTaxes(@WebParam(name = "totalPriceWithoutTaxes") long totalPriceWithoutTaxes, @WebParam(name = "vat") int vat) {
        //TODO write your implementation code here:
        return Long.toString(totalPriceWithoutTaxes + (totalPriceWithoutTaxes*vat/100));
    }
}
