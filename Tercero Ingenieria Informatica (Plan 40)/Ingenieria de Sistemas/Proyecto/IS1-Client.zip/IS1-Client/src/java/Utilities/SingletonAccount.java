/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities;

import DB.Usuarios;

/**
 *
 * @author Lab-DIS
 */
public class SingletonAccount {
    private static Usuarios instance;

    private SingletonAccount(Usuarios instance) {
        this.instance = instance;
    }

    public static Usuarios getInstance(Usuarios user) {
        if(instance == null){
            instance = user;
        }
        return instance;
    }
    
    public static Usuarios getCurrentInstance(){
        return instance;
    }
    
    public static void unsetInstance(){
        instance = null;
    }
    
    
    
    
}
