/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities;

import WS_ServidorHora.JerseyServidorHora;
import WS_ServidorHora.Hora;
import WS_OLDBSportsData.OLDB_AvailableLeagues;
import DB.Usuarios;
import com.google.gson.Gson;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import Utilities.SingletonAccount;

/**
 *
 * @author Lab-DIS
 */
public class ProjectUtils {
    public static String getCurrentHour() {
        try {
            JerseyServidorHora cliente = new JerseyServidorHora ();
            JSONObject jsonObject = new JSONObject(cliente.getJson(String.class));;
            String resultOfJson = jsonObject.toString();
            Gson gson = new Gson();
            Hora res = (Hora) gson.fromJson(resultOfJson, Hora.class);
            return res.getHora();
        } catch (JSONException ex) {
            Logger.getLogger(OLDB_AvailableLeagues.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }    

    public static String getNavBar() {
            Usuarios user = SingletonAccount.getInstance(null);
            String cuenta = user.getCuenta();
            //String cuenta = "Prueba";           
            if(cuenta.length() > 0 ){
                cuenta = "<li class='right'><a href='MyBookings'>Mis Reservas</a></li>"
                        + "<li class='right'><a>"+cuenta+"</a></li>"
                        + "<li class='right'><a href='Logout'>Salir</a></li>";
            } else {
                cuenta = "";
            }
            String res = ("<div>"
                    + "<h1>RESERVA FAN</h1>"
                    + "</div>"
                    + "<div class='main_navbar'>"
                    + "<ul>"
                    + "<li class='left'><a href=\"./External_WS_AvailableLeagues\">Hacer reserva</a></li>"
                    + "<li class='left'><a href='./'>Sobre Nosotros</a></li>"
                    + "<li class='right'><a>"+getCurrentHour()+"</a></li>"
                    + cuenta
                    + "</ul>"
                    + "</div>");
            return res;
    }
}
