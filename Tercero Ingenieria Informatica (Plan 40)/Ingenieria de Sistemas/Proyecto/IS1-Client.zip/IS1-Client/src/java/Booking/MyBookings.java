/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Booking;

import DB.management.DBBookingLoader;
import DB.Reservas;
import DB.Usuarios;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Utilities.ProjectUtils;
import Utilities.SingletonAccount;

/**
 *
 * @author Lab-DIS
 */
@WebServlet(name = "MyBookings", urlPatterns = {"/MyBookings"})
public class MyBookings extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        SingletonAccount.getCurrentInstance().setReservasCollection(null);
        DBBookingLoader cargadorReservas = new DBBookingLoader();
        loadBookings(SingletonAccount.getCurrentInstance(), cargadorReservas);
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Mis Reservas</title>");
            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
            out.println("<link rel='stylesheet' href='./bookings.css'>");
            out.println("<link rel='stylesheet' href='./style.css'>");
            out.println("</head>");
            out.println("<body>");
            out.println(ProjectUtils.getNavBar());
            out.println("<div class='content'>");
            for (Reservas reserva : SingletonAccount.getCurrentInstance().getReservasCollection()) {
                out.println("<div class='booking'>");
                out.println("<div class='innerForm'>");
                out.println("<form method='POST' action='./BookingPrint'>");
                out.println("<div class='inner'>"); 
                out.println("<ul>" +
                            "<h2>Datos de la Reserva</h2>" +
                            "<li><b>Fecha del partido: </b>" + reserva.getFechaPartido() + "</li>" +
                            "<li><b>ID de la Reserva: </b>" + reserva.getToken() + "</li>" +
                            "<li><b>Usuario asociado: </b>" + reserva.getCuentaAsociada().getCuenta() + "</li>" +
                            "<li><b>Total: </b>" + reserva.getTotal() + "€</li>" +
                            "</ul>");
                out.println("</div>");
                out.println("<div class='inner'>");
                out.println("<input type='radio' id='eur' name='currency' value='EUR' checked>");
                out.println("<label for='eur'>EUR</label><br>");
                out.println("<input type='radio' id='gbp' name='currency' value='GBP'>");
                out.println("<label for='gbp'>GBP</label><br>");
                out.println("<input type='radio' id='usd' name='currency' value='USD'>");
                out.println("<label for='usd'>USD</label><br>");
                out.println("</div>"); 
                out.println("<div class='innerButton'>");
                out.println("<input type='submit' value='Generar Comprobante'>");
                out.println("<input type='hidden' name='id' value='"+reserva.getToken()+"'>");
                out.println("</div>");
                out.println("</form>");
                out.println("</div>");
                out.println("</div>");
            }
            out.println("</div>");
            out.println("</body>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

        private void loadBookings(Usuarios user, DBBookingLoader cargadorReservas) {
            
        String result = cargadorReservas.findAll_JSON(String.class);
        Gson gson = new Gson();
        Type reservasClass = new TypeToken<ArrayList<Reservas>>() {}.getType();
        ArrayList listaReservas = gson.fromJson(result, reservasClass);
        
        //Los objetos entran como objects pero se pueden castear
        for (Object reserva : listaReservas) {
            if (reserva instanceof Reservas){
                Reservas current = (Reservas) reserva;
                Usuarios currentUser = SingletonAccount.getCurrentInstance();
                if(current.getCuentaAsociada().getCuenta().equals(currentUser.getCuenta())){
                    SingletonAccount.getCurrentInstance().getReservasCollection().add(current);
                }
            }
        }
        cargadorReservas.close();
    }
    
}
