/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import java.util.ArrayList;
import java.util.List;

public class Usuarios {
    
    private String cuenta;
    private String clave;
    private List<Reservas> reservasCollection;
    
    public Usuarios() {
    }

    public Usuarios(String cuenta) {
        this.cuenta = cuenta;
    }

    public Usuarios(String cuenta, String clave) {
        this.cuenta = cuenta;
        this.clave = clave;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCuenta() {
        return this.cuenta;
    }
    
    public List<Reservas> getReservasCollection() {
        if(this.reservasCollection == null){
            this.reservasCollection = new ArrayList<>();
        }
        return reservasCollection;
    }

    public void setReservasCollection(List<Reservas> reservasCollection) {
        this.reservasCollection = reservasCollection;
    }

}
