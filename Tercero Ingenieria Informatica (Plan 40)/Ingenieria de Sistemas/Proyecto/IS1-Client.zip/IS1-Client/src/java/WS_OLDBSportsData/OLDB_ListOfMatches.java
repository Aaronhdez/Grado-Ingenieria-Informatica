/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WS_OLDBSportsData;

import Utilities.ProjectUtils;
import de.msiggi.sportsdata.webservices.ArrayOfFussballdaten;
import de.msiggi.sportsdata.webservices.ArrayOfMatchdata;
import de.msiggi.sportsdata.webservices.Matchdata;
import de.msiggi.sportsdata.webservices.Sportsdata;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author Lab-DIS
 */
@WebServlet(name = "ListOfMatches", urlPatterns = {"/ListOfMatches"})
public class OLDB_ListOfMatches extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/www.openligadb.de/Webservices/Sportsdata.asmx.wsdl")
    private Sportsdata service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @SuppressWarnings("empty-statement")
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<link rel='stylesheet' href='./match.css'>");
            out.println("<link rel='stylesheet' href='./style.css'>");
            out.println("<title>Jornada: "+request.getParameter("jornada")+"</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println(ProjectUtils.getNavBar());
            out.println("<div class='content'>");
            out.println("<div class='box'>");
            out.println("<div class='row upper'>");
            out.println("<div class='datarow row_right'>");
            out.println("</div>");
            out.println("<div class='datarow row_left'>");
            out.println("<p> Jornada "+ request.getParameter("jornada") +"</p>");
            out.println("</div>");
            out.println("</div>");
            List<String> info = new ArrayList<>();
            info.add(request.getParameter("leaguesaison"));
            info.add(request.getParameter("idleague"));
            info.add(request.getParameter("leagueID"));
            info.add(request.getParameter("jornada"));
            
            int p = 0;
            for(Matchdata datosPartido: getMatchdataByLeagueSaison(request.getParameter("idleague"),request.getParameter("leaguesaison")).getMatchdata()){
                if(datosPartido.getGroupOrderID() == Integer.parseInt(request.getParameter("jornada"))){
                    out.println("<div class='matchRow'>");
                    out.println("<div class='box-body row'>");
                    out.println("<div class='data inner_left'>");
                    out.println("<div class='divteam'>" + datosPartido.getNameTeam1() + "  "
                            + "</div><div class='divicon'><img src='" + datosPartido.getIconUrlTeam1() + "'></div>");
                    out.println("</div>");
                    
                    Date matchDate = toDate(datosPartido.getMatchDateTime());
                    Date today = new Date();
                    out.println("<div class='data inner'>");
                    
                    int hours = + matchDate.toInstant().atZone(ZoneId.systemDefault()).getHour();
                    int minutes = + matchDate.toInstant().atZone(ZoneId.systemDefault()).getMinute();
                    int days = + matchDate.toInstant().atZone(ZoneId.systemDefault()).getDayOfMonth();
                    int month = + matchDate.toInstant().atZone(ZoneId.systemDefault()).getMonthValue();
                    int year = + matchDate.toInstant().atZone(ZoneId.systemDefault()).getYear();
                    String dateBook = days+"/"+month+"/"+year+" "+hours+":"+minutes;
                    
                    if(matchDate.after(today)){
                        out.println("<div>X - X</div>");
                        out.println("<div>"+hours+":"+minutes+"</div>");
                        out.println("<div>"+days+"/"+month+"/"+year+"</div>");
                        out.println("<div class='submitButton'>"+printButton(datosPartido, dateBook, info)+"</div>");
                        
                    } else if (matchDate.before(today)){
                        out.println("<div>Ya se jugó</div>");
                        out.println("<div>"+hours+":"+minutes+"</div>");
                        out.println("<div>"+days+"/"+month+"/"+year+"</div>");
                            out.println("<div class='submitButton'>"+printDisabledButton()+"</div>");
                    } else {
                        if(matchDate.getTime() < today.getTime()){
                            out.println("<div>X - X</div>");
                            out.println("<div>"+hours+":"+minutes+"</div>");
                            out.println("<div>"+days+"/"+month+"/"+year+"</div>");
                            out.println("<div class='submitButton'>"+printButton(datosPartido, dateBook, info)+"</div>");
                        } else {
                            out.println("<div>Ya se jugó</div>");
                            out.println("<div>"+hours+":"+minutes+"</div>");
                            out.println("<div>"+days+"/"+month+"/"+year+"</div>");
                            out.println("<div class='submitButton'>"+printDisabledButton()+"</div>");
                        }
                    }
                    
                    out.println("</div>");
                    out.println("<div class='data inner_right'>");
                    out.println("<div class='divicon'><img src='" + datosPartido.getIconUrlTeam2() + "'></div>  "
                            + "<div class='divteam'>"+datosPartido.getNameTeam2()+ "</div>");
                    out.println("</div>");
                    out.println("</div>");
                    out.println("</div>");
                    p++;
                }
            }
            int jornada = Integer.parseInt(request.getParameter("jornada"));
            int t = (((p*2)-1)*2);
            out.println("<div class='row lower'>");
            out.println("<div class='datarow row_right'>");
            out.println("<p>Jornada " + request.getParameter("jornada") + " de " + t + "</p>");
            out.println("</div>");
            out.println("<div class='data inner_row'>");
            if(jornada != 1){
                out.println("<form action='' method='GET'><input type='submit' value='<'>"
                        +"<input type='hidden' value="+request.getParameter("leaguesaison")+" name='leaguesaison'>"
                        +"<input type='hidden' value="+request.getParameter("idleague")+" name='idleague'>"
                        +"<input type='hidden' value="+request.getParameter("leagueID")+" name='leagueID'>"   
                        +"<input type='hidden' value="+(jornada-1)+" name='jornada'>" 
                        + "</form>");
            }
            if(jornada != t){
                out.println("<form action='' method='GET'><input type='submit' value='>'>"
                        +"<input type='hidden' value="+request.getParameter("leaguesaison")+" name='leaguesaison'>"
                        +"<input type='hidden' value="+request.getParameter("idleague")+" name='idleague'>"
                        +"<input type='hidden' value="+request.getParameter("leagueID")+" name='leagueID'>"    
                        +"<input type='hidden' value="+(jornada+1)+" name='jornada'>" 
                        + "</form>");
            }
            out.println("</div>");
            out.println("<div class='datarow row_left'>");
            out.println("<p>Temporada "+request.getParameter("leaguesaison")+"</p>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            out.println("</div>");
            //leaguesaison

            
            out.println("</body>");
            out.println("</html>");
       }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    /*
     * Converts XMLGregorianCalendar to java.util.Date in Java
     */
    public static Date toDate(XMLGregorianCalendar calendar){
        if(calendar == null) {
            return null;
        }
        return calendar.toGregorianCalendar().getTime();
    }
    
    private String printButton(Matchdata datosPartido, String dateBook, List info) {
        return "<form action='./BookingServlet' method='POST'>"
                + "<input type='submit' value='reservar'>"
                + "<input type='hidden' name='league' value='"+datosPartido.getLeagueName()+"'>"
                + "<input type='hidden' name='team1' value='"+datosPartido.getNameTeam1()+"'>"
                + "<input type='hidden' name='team2' value='"+datosPartido.getNameTeam2()+"'>"
                + "<input type='hidden' name='matchId' value='"+datosPartido.getMatchID()+"'>"
                + "<input type='hidden' name='leaguesaison' value='"+info.get(0)+"'>"
                + "<input type='hidden' name='idleague' value='"+info.get(1)+"'>"
                + "<input type='hidden' name='leagueID' value='"+info.get(2)+"'>"
                + "<input type='hidden' name='jornada' value='"+info.get(3)+"'>"
                + "<input type='hidden' name='date' value='"+dateBook+"'>"
                + "</form>";
    }
    
    private String printDisabledButton() {
        return "<form>"
                + "<input type='submit' value='reservar' disabled>"
                + "</form>";
    }
   

    private ArrayOfMatchdata getMatchdataByLeagueSaison(java.lang.String leagueShortcut, java.lang.String leagueSaison) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        de.msiggi.sportsdata.webservices.SportsdataSoap port = service.getSportsdataSoap();
        return port.getMatchdataByLeagueSaison(leagueShortcut, leagueSaison);
    }

}
